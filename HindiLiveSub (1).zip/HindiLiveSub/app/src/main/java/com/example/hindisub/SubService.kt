package com.example.hindisub

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

class SubService : Service() {
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    @Volatile private var running = false
    private var overlay: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.HINDI).build()
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "sub"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Subtitles", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Hindi subtitles chal rahe hain")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {}, ui)

        addOverlay()
        show("Hindi model download ho raha hai (pehli baar internet chahiye)...")
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { show("Taiyaar. Video chalao."); startWork() }
            .addOnFailureListener { show("Translation model download fail. Internet check karo.") }
        return START_NOT_STICKY
    }

    private fun addOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            setTextColor(Color.WHITE); setBackgroundColor(0xAA000000.toInt())
            textSize = 18f; setPadding(24, 16, 24, 16); gravity = Gravity.CENTER
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM; y = 220 }
        wm.addView(overlay, lp)
    }

    private fun show(t: String) = ui.post { overlay?.text = t }

    // Vosk English model pehli baar internet se download hota hai (~40MB)
    private fun downloadModel(dir: File) {
        val url = java.net.URL("https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip")
        java.util.zip.ZipInputStream(url.openStream().buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val rel = e.name.substringAfter('/', "")
                if (rel.isNotEmpty()) {
                    val f = File(dir, rel)
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { zin.copyTo(it) }
                    }
                }
                e = zin.nextEntry
            }
        }
    }

    private fun startWork() {
        running = true
        Thread {
            try {
                val dir = File(filesDir, "model-en")
                if (!File(dir, "am").exists()) {
                    show("Speech model download ho raha hai (40MB, ek baar)...")
                    dir.deleteRecursively(); downloadModel(dir)
                    show("Taiyaar. Video chalao.")
                }
                val rec = Recognizer(Model(dir.absolutePath), 16000f)

                val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
                val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(16000).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
                record = AudioRecord.Builder().setAudioFormat(fmt)
                    .setBufferSizeInBytes(16000 * 2).setAudioPlaybackCaptureConfig(cfg).build()
                record!!.startRecording()

                val buf = ByteArray(4096)
                var lastPartial = ""
                var lastTranslate = 0L
                while (running) {
                    val n = record!!.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    if (rec.acceptWaveForm(buf, n)) {
                        val text = JSONObject(rec.result).optString("text")
                        if (text.isNotBlank()) translate(text)
                        lastPartial = ""
                    } else {
                        val p = JSONObject(rec.partialResult).optString("partial")
                        val now = System.currentTimeMillis()
                        if (p.isNotBlank() && p != lastPartial && now - lastTranslate > 700) {
                            lastPartial = p; lastTranslate = now; translate(p)
                        }
                    }
                }
            } catch (e: Exception) {
                show("Error: ${e.message}")
            }
        }.start()
    }

    private fun translate(en: String) {
        translator.translate(en).addOnSuccessListener { show(it) }
    }

    override fun onDestroy() {
        running = false
        record?.stop(); record?.release()
        projection?.stop()
        translator.close()
        overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }
}
