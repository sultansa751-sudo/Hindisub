Is project ko GitHub Actions se build karo (steps chat me diye hain).
Pehli baar app chalane par English speech model (~40MB) aur Hindi translation model apne aap download honge.
